import sys
import os
from pyspark import SparkContext
from math import ceil, floor
import json
from time import time
from urllib import quote


def prepare_src_files(conf):
    src = []

    for e in conf['allowed_events']:
        dir = os.path.join(conf['data_dir'], conf['instance'], conf['company'], 'add_event', quote(e))
        if os.direxists(dir):
            src.append(os.path.join(dir,conf['date'],"/*"))

#    if '__all_events__' in app_conf.get('allowed_events'):

    # if app_conf.get('target_event'):
    #     src.append("maprfs:///data/archive/{0}/{1}/add_event/{2}/2015-11-*9/*".
    #                format(app_conf['instance'],
    #                app_conf['company'],
    #                quote(app_conf['target_event'])))

    # for c in app_conf.get('allowed_events'):
    #     if c != "__all_events__":
    #         src.append("maprfs:///data/archive/{0}/{1}/add_event/{2}/2015-11-*9/*".
    #                     format(app_conf['instance'],
    #                     app_conf['company'],
    #                     quote(c)))

    return ",".join(src)


def str_input_to_json_events(data):
    try:
        event = json.loads(data)
    except:
        return

    if event.get('type') == 'add_event' and event['data'].get('customer_id'):
        yield event['data']


def derive_attributes(target_event_type):
    def wrapped(customer):
        customer_id, events = customer

        target_event = 0
        events_count = 0
        events_sorted = sorted(events, key=lambda k: k['timestamp'], reverse=False)

        for e in events_sorted:
            events_count += 1
            target_event_timestamp = e['timestamp']

            if e['type'] == target_event_type:
                target_event = 1
                del events_sorted[events_count:]
                break

        events_truncated = sorted(events_sorted, key=lambda k: k['timestamp'], reverse=True)
        results = {'customer_id': customer_id,
                   'target_event': target_event,
                   'target_events_ts': target_event_timestamp}

        first_attributes = []
        for e in events_truncated:
            if e['type'] == target_event_type:
                continue

            days = floor((target_event_timestamp - e['timestamp']) / (60*60*24))
            mins = floor((target_event_timestamp - e['timestamp']) / 60)
            secs = floor((target_event_timestamp - e['timestamp']))

            for period in [3]:
                attribute = "count_"+e['type']+"_"+str(period)+'d'
                if days < period:
                    if attribute in results:
                        results[attribute] += 1
                    else:
                        results[attribute] = 1

            if e['type'] not in first_attributes:
                first_attributes.append(e['type'])
                attribute = "last_"+e['type']+"_secs"
                results[attribute]=secs

            attribute = "first_"+e['type']+"_secs"
            results[attribute]=secs

        return json.dumps(results)
    return wrapped


def derive_attributes_churn(target_event_type):

    def extend_with_props_of_last_event(results, e):
        for prop_name, prop_value in e['properties'].iteritems():
            attribute = "lval_"+e['type']+"_"+prop_name
            results[attribute] = prop_value

    def remove_events_before_target(events_sorted):
        last_activity_ts = 0
        for i, e in enumerate(events_sorted):
            if e['type'] == 'campaign' and e['properties'].get('status') == 'delivered':
                last_activity_ts = e['timestamp']
                del events_sorted[:i]
                break
        return last_activity_ts

    def extend_attribute_counts(results, periods, e, days):
        for period in periods:
            attribute = "c{0}d_{1}".format(period, e['type'])

            if days < period:
                if attribute in results:
                    results[attribute] += 1
                else:
                    results[attribute] = 1

    def wrapped(customer):

        customer_id, events = customer
        last_activity = 0
        first_attributes = []

        events_sorted = sorted(events, key=lambda k: k['timestamp'], reverse=True)

        # find the first activity event and delete it together with all events before it
        last_activity_ts = remove_events_before_target(events_sorted)
        if last_activity_ts == 0 or len(events_sorted) == 0:
            return

        target_churn = 0 if last_activity_ts > time() - 7*24*3600 else 1
        results = {'customer_id': customer_id,
                   'target_event': target_churn,
                   'target_events_ts': last_activity}

        # time of the most recent event while customers was still active
        target_event_timestamp = events_sorted[0]['timestamp']

        # aggregate all remaining events
        for e in events_sorted:

            # skip unwanted events
            if e['type'] in ['campaign', 'Nightly']:
                continue

            days = (target_event_timestamp - e['timestamp']) / (60*60*24)

            #add counts of events in last [1,3,7,28] days
            extend_attribute_counts(results, [3], e, days)

            # add days from the last event (the first in reverse order, add first and block others)
            if e['type'] not in first_attributes:
                first_attributes.append(e['type'])
                results["dLast_{0}".format(e['type'])] = days

            # add days from the first event
            results["dFirst_{0}_days".format(e['type'])] = days

            #extend_with_props_of_last_event(results, e)

        yield json.dumps(results)

    return wrapped



def derive_attributes_churn_no_comment(target_event_type):

    def extend_with_props_of_last_event(results, e):
        for prop_name, prop_value in e['properties'].iteritems():
            attribute = "lval_"+e['type']+"_"+prop_name
            results[attribute] = prop_value

    def remove_events_before_target(events_sorted):
        for i, e in enumerate(events_sorted):
            if e['type'] == 'campaign' and e['properties'].get('status') == 'delivered':
                last_activity_ts = e['timestamp']
                del events_sorted[:i]
                break
        return last_activity_ts

    def extend_attribute_counts(results, periods, e, days):
        for period in periods:
            attribute = "c{0}d_{1}".format(period, e['type'])

            if days < period:
                if attribute in results:
                    results[attribute] += 1
                else:
                    results[attribute] = 1

    def wrapped(customer):

        customer_id, events = customer
        last_activity = 0
        first_attributes = []

        events_sorted = sorted(events, key=lambda k: k['timestamp'], reverse=True)

        last_activity_ts = remove_events_before_target(events_sorted)

        if last_activity_ts == 0 or len(events_sorted) == 0:
            return

        target_churn = 0 if last_activity_ts > time() - 7*24*3600 else 1
        results = {'customer_id': customer_id,
                   'target_event': target_churn,
                   'target_events_ts': last_activity}

        target_event_timestamp = events_sorted[0]['timestamp']

        for e in events_sorted:

            if e['type'] in ['campaign', 'Nightly']:
                continue

            days = (target_event_timestamp - e['timestamp']) / (60*60*24)
            extend_attribute_counts(results, [3], e, days)

            # if e['type'] not in first_attributes:
            #     first_attributes.append(e['type'])
            #     results["dLast_{0}".format(e['type'])] = days

            # results["dFirst_{0}_days".format(e['type'])] = days

            # extend_with_props_of_last_event(results, e)

        return json.dumps(results)

    return wrapped